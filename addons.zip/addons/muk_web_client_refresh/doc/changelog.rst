`2.2.0`
-------

- Automatically initiate refresh rules

`2.1.0`
-------

- Reduced unnecessary refresh calls

`2.0.0`
-------

- Migrated to Python 3
- Replaced Auto Refresh Rule by Automated Action

`1.0.0`
-------

- Init version
