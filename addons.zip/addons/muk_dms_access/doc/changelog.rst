`2.0.0`
-------

- Migrated to Python 3
- Updated dependencies
- Updated database models

`1.0.0`
-------

- Init version
