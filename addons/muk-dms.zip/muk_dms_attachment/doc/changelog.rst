`2.1.0`
-------

- File Actions

`2.0.0`
-------

- Migrated to Python 3
- Updated dependencies
- Updated database models

`1.2.0`
-------

- New methods

`1.1.0`
-------

- Updated dependencies

`1.0.0`
-------

- Init version
