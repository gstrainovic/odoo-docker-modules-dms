`1.5.0`
-------

- Added Group Access Mixin

`1.4.0`
-------

- Added Access Mixin

`1.3.0`
-------

- Added Locking Mixin

`1.2.0`
-------

- Restructuring

`1.1.0`
-------

- Updated dependencies

`1.0.0`
-------

- Init version
