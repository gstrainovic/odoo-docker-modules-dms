`1.2.0`
-------

- Mobile Support

`1.1.0`
-------

- Lazy Loading on long requests

`1.0.0`
-------

- Init version

