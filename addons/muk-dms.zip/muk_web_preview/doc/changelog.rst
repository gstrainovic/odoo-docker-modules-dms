`2.3.0`
-------

- Sidebar Preview

`2.2.0`
-------

- Refactoring and Preview Registry

`2.1.0`
-------

- Added Settings to install Extensions

`2.0.0`
-------

- Migrated to Python 3
- Libraries moved to Web Utils

`1.1.0`
-------

- Lazy load javascript

`1.0.0`
-------

- Init version
