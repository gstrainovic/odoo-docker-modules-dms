`1.6.0`
-------

- Override Attachment to make it more extendable

`1.5.0`
-------

- Storage Migration Action

`1.4.0`
-------

- Added Hierarchy Mixin

`1.3.0`
-------

- Added SCSS Editor

`1.2.0`
-------

- Added Group Mixin

`1.1.0`
-------

- Added Storage Settings

`1.0.0`
-------

- Init Version
